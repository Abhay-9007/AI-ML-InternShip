from flask import Flask, render_template, request
import tensorflow as tf
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import numpy as np
import os

app = Flask(__name__)

# Load your model
model = tf.keras.models.load_model('model/scaphoid_detector.keras')
class_names = ['Normal', 'Scaphoid Injury']

UPLOAD_FOLDER = 'static/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html', prediction=None, image_path=None)

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return render_template('index.html', prediction="No image uploaded", image_path=None)

    file = request.files['image']
    if file.filename == '':
        return render_template('index.html', prediction="No file selected", image_path=None)

    # Save uploaded image
    image_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(image_path)

    # Preprocess image
    img = load_img(image_path, target_size=(224, 224), color_mode='grayscale')
    img_array = img_to_array(img) / 255.0
    img_array = np.expand_dims(img_array, axis=0)

    # Predict
    prediction = model.predict(img_array)[0][0]
    label = class_names[1] if prediction > 0.5 else class_names[0]

    return render_template('index.html', prediction=label, image_path=image_path)

if __name__ == '__main__':
    app.run(debug=True)
